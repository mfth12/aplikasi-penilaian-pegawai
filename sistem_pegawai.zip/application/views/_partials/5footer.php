                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Al-Madinah - 2020</div>
                            <!-- <?php echo " ". Date('M') . " " . Date('Y') ?> -->
                            <div>
                                <span class="text-muted"> Data diproses dalam <strong>{elapsed_time}</strong> detik
                                </span>
                                <!-- &middot;
                                <span> <a href="#">Kebijakan & Privasi</a>
                                </span> -->
                            </div>
                        </div>
                    </div>
                </footer>