<?php

class Input_pengajuan extends CI_Controller {
    public function __construct()
    {
		parent::__construct();
		//sd mulai menggunakan method user model dan pemeriksaan login
		$this->load->model("UserModel");
		$this->UserModel->terotentikasi();
		//setelah itu modeluser
		//$this->load->model("user_model");
		// if($this->user_model->isNotLogin()) redirect(site_url(''));
	}

	public function index()
	{
        // sedang dalam maintenance
        $this->load->view("_partials/maintenance.php");
	}
}